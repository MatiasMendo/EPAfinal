//server Falabella
const { get } = require('./config/config');
const bodyParser = require('body-parser');
const log = require('./middlewares/log');
const mongoose = require('mongoose');
const express = require('express');
const https = require('https');
//const http = require('http');
const fs = require('fs');
const ip = require('ip');
const dotenv = require('dotenv');
const path = require('path');

require('dotenv').config();
const app = express()
const logger = log.create(__filename)

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
    next();
});

app.use(require('./routes/index.js'));

dotenv.config({
    path: path.join(__dirname, '.env')
});

let cert_pem = "/root/EPA_2024-07-24/EPA_2024-07-24/wildcard_tod_cl.pem";

//let cert_crt = "/opt/sixbell/WebApp/certificados/sixbell.crt";
//let cert_ca = "/opt/sixbell/WebApp/certificados/rootCA.crt";

let credentials = {
    key: fs.readFileSync(cert_pem), // Usa el archivo .pem para la clave y el certificado
    cert: fs.readFileSync(cert_pem), // Normalmente, el archivo .pem contiene tanto la clave como el certificado
    requestCert: false,
    rejectUnauthorized: false
};
let httpsServer = https.createServer(credentials, app);

httpsServer.listen(process.env.PORT, async function () {
    const cfg = log.initiate(logger, undefined, 'app.listen');
    console.clear();

    log.info(cfg, `server listen >> ${ip.address()}:`, process.env.PORT);

    const connectionString = `mongodb://${process.env.MONGODB_USER}:${process.env.MONGODB_PASS}@${process.env.MONGODB_URL}/${process.env.MONGODB_DATABASE}`;

    await mongoose.connect(connectionString, {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    }).then(() => {
        log.info(cfg, 'MongoDB connected [' + process.env.MONGODB_URL + '/' + process.env.MONGODB_DATABASE + ']');
    }).catch(error => {
        log.error(cfg, 'No se ha logrado conectar a MongoDb :', error);
        process.exit(1);
    });
});




